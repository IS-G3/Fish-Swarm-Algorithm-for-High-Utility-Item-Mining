import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class HUIM_AF {
    private List<int[]> population;
    private List<int[]> SHUI;
    private int maxIter;
    private double minUtil;
    private int tryNumber;
    private List<Transaction> transactions;
    private int VD;
    private int populationSize;

    public HUIM_AF(int populationSize, int maxIter, double minUtil, int tryNumber, List<Transaction> transactions, int VD) {
        this.population = new ArrayList<>();
        this.SHUI = new ArrayList<>();
        this.maxIter = maxIter;
        this.minUtil = minUtil;
        this.tryNumber = tryNumber;
        this.transactions = transactions;
        this.VD = VD;
        this.populationSize = populationSize;
    }

    public void runHUIM_AF() {
        initializePopulation();
        SHUI.clear();
        int iter = 1;

        while (iter <= maxIter) {
            for (int i = 0; i < population.size(); i++) {
                boolean isFollow = false;
                boolean isSwarm = false;

                population.set(i, follow(population.get(i)));
                if (!isFollow) {
                    swarm(population.get(i));
                }
                if (!isFollow && !isSwarm) {
                    prey(population.get(i));
                }
            }
            iter++;
        }

        outputHUIs();
    }

    private void initializePopulation() {
        population.clear();

        Random random = new Random();
        for (int i = 0; i < populationSize; i++) {
            int[] p = new int[transactions.get(0).getItems().length];

            for (int j = 0; j < transactions.get(0).getItems().length; j++) {
                p[j] = random.nextInt(2);
            }

            population.add(p);
        }
    }

    private int[] follow(int[] fish) {
        boolean isFollow = false;
        int[] best_AF = new int[fish.length];
        System.arraycopy(fish, 0, best_AF, 0, fish.length);
        int dis = 0;

        for (int i = 0; i < population.size(); i++) {
            int diff = bitDiff(fish, population.get(i));
            double fitnessFish = calculateFitness(fish, transactions);
            double fitnessBestAF = calculateFitness(best_AF, transactions);

            if (diff <= VD && fitnessFish > fitnessBestAF) {
                best_AF = population.get(i);
                dis = diff;
            }
        }

        int disPrime = bitDiff(best_AF, fish);
        if (disPrime > 0) {
            isFollow = true;
            Random random = new Random();
            int k = random.nextInt(disPrime);
            bitwiseComplement(fish, k);

            double fitnessFish = calculateFitness(fish, transactions);
            if (fitnessFish >= minUtil && !isContainedInSHUI(fish)) {
                SHUI.add(fish);
            }
        }

        return fish;
    }

    private int bitDiff(int[] fish1, int[] fish2) {
        int diffCount = 0;
        for (int i = 0; i < fish1.length; i++) {
            if (fish1[i] != fish2[i]) {
                diffCount++;
            }
        }
        return diffCount;
    }

    private void bitwiseComplement(int[] fish, int k) {
        Random random = new Random();
        int count = 0;
        while (count < k) {
            int index = random.nextInt(fish.length);
            fish[index] = 1 - fish[index];
            count++;
        }
    }

    private boolean isContainedInSHUI(int[] fish) {
        for (int[] hui : SHUI) {
            if (bitDiff(fish, hui) == 0) {
                return true;
            }
        }
        return false;
    }

    private double calculateFitness(int[] itemset, List<Transaction> transactions) {
        double fitness = 0.0;

        for (Transaction transaction : transactions) {
            double transactionUtility = calculateTransactionUtility(itemset, transaction);
            fitness += transactionUtility;
        }

        return fitness;
    }

    private double calculateTransactionUtility(int[] itemset, Transaction transaction) {
        double transactionUtility = 0.0;

        for (int i = 0; i < itemset.length; i++) {
            if (itemset[i] == 1) {
                String item = transaction.getItem(i);
                double itemUtility = transaction.getItemUtility(item);
                transactionUtility += itemUtility;
            }
        }

        return transactionUtility;
    }

    private void swarm(int[] fish) {
        int NH = fish.length; // Number of elements in fish (assuming each element corresponds to an AF)
        int[] count_zero = new int[NH];
        int[] count_one = new int[NH];

        for (int j = 0; j < NH; j++) {
            count_zero[j] = 0;
            count_one[j] = 0;
        }

        for (int i = 0; i < population.size(); i++) {
            int dis = bitDiff(fish, population.get(i));

            if (dis <= VD) {
                for (int j = 0; j < NH; j++) {
                    if (population.get(i)[j] == 0) {
                        count_zero[j]++;
                    } else {
                        count_one[j]++;
                    }
                }
            }
        }

        int[] Cen_AF = new int[NH];
        for (int j = 0; j < NH; j++) {
            if (count_one[j] >= count_zero[j]) {
                Cen_AF[j] = 1;
            } else {
                Cen_AF[j] = 0;
            }
        }

        if (calculateFitness(Cen_AF, transactions) >= minUtil && !isContainedInSHUI(Cen_AF)) {
            SHUI.add(Cen_AF);
        }

        if (calculateFitness(fish, transactions) < calculateFitness(Cen_AF, transactions)) {
            boolean isSwarm = true;
            int disPrime = bitDiff(Cen_AF, fish);

            Random random = new Random();
            int k = random.nextInt(disPrime);
            bitwiseComplement(fish, k);

            if (calculateFitness(fish, transactions) >= minUtil && !isContainedInSHUI(fish)) {
                SHUI.add(fish);
            }
        }
    }

    private void prey(int[] fish) {
        boolean flag = false;
        int times = 1;

        while (times <= tryNumber) {
            Random random = new Random();
            int k = random.nextInt(VD);
            int[] P_prime = new int[fish.length];
            System.arraycopy(fish, 0, P_prime, 0, fish.length);
            bitwiseComplement(P_prime, k);

            if (calculateFitness(P_prime, transactions) >= minUtil && !isContainedInSHUI(P_prime)) {
                SHUI.add(P_prime);
            }

            if (calculateFitness(P_prime, transactions) > calculateFitness(fish, transactions)) {
                fish = P_prime;
                flag = true;
                break;
            }

            times++;
        }

        if (!flag) {
            Random random = new Random();
            int[] P_prime = new int[fish.length];
            System.arraycopy(fish, 0, P_prime, 0, fish.length);

            for (int i = 0; i < fish.length; i++) {
                if (random.nextDouble() < 0.5) {
                    P_prime[i] = 1 - P_prime[i];
                }
            }

            if (calculateFitness(P_prime, transactions) >= minUtil && !isContainedInSHUI(P_prime)) {
                SHUI.add(P_prime);
            }
        }
    }

    private void outputHUIs() {
        System.out.println("Discovered HUIs:");
        for (int[] hui : SHUI) {
            StringBuilder huiString = new StringBuilder();
            for (int item : hui) {
                huiString.append(item);
            }
            System.out.println(huiString.toString());
        }
    }

    public static void main(String[] args) {
        // Create a sample transaction database
        List<Transaction> transactions = new ArrayList<>();

        Transaction t1 = new Transaction(1, 4);
        t1.setItems(new String[]{"A", "B", "C", "D"});
        t1.addItem("B", 1);
        t1.addItem("C", 2);
        t1.addItem("D", 1);
        t1.addItem("F", 2);
        transactions.add(t1);

        Transaction t2 = new Transaction(2, 5);
        t2.setItems(new String[]{"A", "B", "C", "D", "E"});
        t2.addItem("A", 4);
        t2.addItem("B", 1);
        t2.addItem("C", 3);
        t2.addItem("D", 1);
        t2.addItem("E", 1);
        transactions.add(t2);

        Transaction t3 = new Transaction(3, 3);
        t3.setItems(new String[]{"A", "C", "D"});
        t3.addItem("A", 4);
        t3.addItem("C", 2);
        t3.addItem("D", 1);
        transactions.add(t3);

        Transaction t4 = new Transaction(4, 3);
        t4.setItems(new String[]{"C", "D", "E"});
        t4.addItem("C", 2);
        t4.addItem("D", 1);
        t4.addItem("E", 1);
        transactions.add(t4);

        Transaction t5 = new Transaction(5, 4);
        t5.setItems(new String[]{"A", "B", "D", "E"});
        t5.addItem("A", 5);
        t5.addItem("B", 2);
        t5.addItem("D", 1);
        t5.addItem("E", 2);
        transactions.add(t5);

        Transaction t6 = new Transaction(6, 4);
        t6.setItems(new String[]{"A", "B", "C", "D"});
        t6.addItem("A", 3);
        t6.addItem("B", 4);
        t6.addItem("C", 1);
        t6.addItem("D", 1);
        transactions.add(t6);

        Transaction t7 = new Transaction(7, 3);
        t7.setItems(new String[]{"D", "E", "F"});
        t7.addItem("D", 1);
        t7.addItem("E", 1);
        t7.addItem("F", 1);
        transactions.add(t7);


        int populationSize = 5;
        int maxIter = 10;
        double minUtil = 60;
        int tryNumber = 3;
        int VD = 3;

        HUIM_AF huim = new HUIM_AF(populationSize, maxIter, minUtil, tryNumber, transactions, VD);
        huim.runHUIM_AF();
    }
}
