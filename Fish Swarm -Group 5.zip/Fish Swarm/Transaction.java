import java.util.Map;
import java.util.HashMap;

public class Transaction {
    private int id;
    private Map<String, Integer> itemQuantities;
    private String[] items;

    public Transaction(int id, int numItems) {
        this.id = id;
        this.itemQuantities = new HashMap<>();
        this.items = new String[numItems];
    }

    public void addItem(String item, int quantity) {
        itemQuantities.put(item, quantity);
    }

    public void setItems(String[] items) {
        this.items = items;
    }

    public String[] getItems() {
        return items;
    }

    public String getItem(int index) {
        if (index >= 0 && index < items.length) {
            return items[index];
        }
        return null;
    }

    public int getId() {
        return id;
    }

    public int getItemUtility(String item) {
        if (itemQuantities.containsKey(item)) {
            int quantity = itemQuantities.get(item);
            int profit = getProfit(item);
            return quantity * profit;
        }
        return 0;
    }

    private int getProfit(String item) {
        // Define the profit values for each item
        switch (item) {
            case "A":
                return 1;
            case "B":
                return 2;
            case "C":
                return 1;
            case "D":
                return 5;
            case "E":
                return 4;
            case "F":
                return 3;
            default:
                return 0;
        }
    }
}
